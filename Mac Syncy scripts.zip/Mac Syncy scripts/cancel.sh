#!/bin/bash
pkill rsync
