#!/bin/bash
#The following line is a hard-coded line that was used for testing
#rsync -a --progress ~/Downloads /Volumes/HDBackups/Primary\ Storage/rsync\ tests

#The following line is the real backup instruction
rsync -av --progress "$1" "$2"
#"$1" and "$2" refer to arguments, source and destination, respectively
